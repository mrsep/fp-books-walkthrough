[The Joy of Clojure](http://joyofclojure.com)
=============================================

![Joy](http://joyofclojure.com/joy.png "The Joy of Clojure")

![Jack](http://joyofclojure.com/cover.jpg "The Joy of Clojure Cover")
